module.exports = {  //FILL IN THE BLANKS!
    host: '',
    port: 3306,
    user: '',
    password: '',
    database: 'profiles'
}